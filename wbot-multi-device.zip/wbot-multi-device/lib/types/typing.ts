export interface packInfo {
    packname?: string
    author?: string
}